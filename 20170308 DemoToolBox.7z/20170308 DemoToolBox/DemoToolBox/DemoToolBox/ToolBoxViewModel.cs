﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoToolBox
{

    public class ToolBoxViewModel //: INotifyPropertyChanged
    {




    }

    public class DesignTimeToolboxViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<ToolboxItemViewModel> _items;//2F root
        public ObservableCollection<ToolboxItemViewModel> Items
        {
            get { return _items; }
        }
        public DesignTimeToolboxViewModel()
        //: base(null, null)
        {
            //[ToolboxItem(typeof(GraphViewModel), "Multiply", "Maths", "pack://application:,,,/Modules/FilterDesigner/Resources/active_x_16xLG.png")]
            _items = new ObservableCollection<ToolboxItemViewModel>();
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "Add", Category = "Math", IconSource= new Uri("pack://application:,,,/Images/action_add_16xLG.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "Color", Category = "Generator", IconSource = new Uri("pack://application:,,,/Images/color_swatch.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "Multiply", Category = "Math", IconSource = new Uri("pack://application:,,,/Images/active_x_16xLG.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "Image Source", Category = "Generator", IconSource = new Uri("pack://application:,,,/Images/image.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "Baz", Category = "Misc" }));

        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnNotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

    public class ToolboxItemViewModel
    {
        private readonly ToolboxItem _model;

        public ToolboxItem Model//1F
        {
            get { return _model; }
        }

        public string Name//寫死0F  leaf
        {
            get { return _model.Name; }
        }

        public virtual string Category//寫死0F
        {
            get { return _model.Category; }
        }

        public virtual Uri IconSource
        {
            get { return _model.IconSource; }
        }

        public ToolboxItemViewModel(ToolboxItem model)
        {
            _model = model;
        }
    }

    public class ToolboxItem
    {
        public Type DocumentType { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public Uri IconSource { get; set; }
        public Type ItemType { get; set; }
    }

}

