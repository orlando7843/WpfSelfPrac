﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Wpf0113
{
    /// <summary>
    /// Window16.xaml 的互動邏輯
    /// </summary>
    public partial class Window16 : Window
    {
        public Window16()
        {
            InitializeComponent();
            
        }
    }

}
