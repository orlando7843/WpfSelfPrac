﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window7.xaml 的互動邏輯
    /// </summary>
    public partial class Window7 : Window
    {
        public Window7()
        {
            InitializeComponent();
        }

        private void shwDlg_Click(object sender, RoutedEventArgs e)
        {
            InputWindowxaml inputWindowxaml = new InputWindowxaml();
            bool? resp = inputWindowxaml.ShowDialog();
            if (resp == null)
            {
                MessageBox.Show("沒設置");
            }
            else if (resp == true)
            {
                MessageBox.Show("點選確定鈕\n"+ inputWindowxaml.View_txtValue);
            }
            else if (resp == false) {
                MessageBox.Show("點選取消鈕");
            }
        }
    }
}
