﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window34.xaml 的互動邏輯
    /// </summary>
    public partial class Window34 : Window
    {
        public Window34()
        {
            InitializeComponent();
            DataContext = new MyItemViewModel();
        }
    }
    class MyItemViewModel
    {
        ObservableCollection<MyItem> _myItems;

        public MyItemViewModel()
        {
            _myItems = new ObservableCollection<MyItem>();
            _myItems.Add(new MyItem(10, 10, "First TextBlock"));
            _myItems.Add(new MyItem(50, 50, "2nd TextBlock"));
            _myItems.Add(new MyItem(75, 25, "The Third TextBlock"));
        }

        public ObservableCollection<MyItem> MyItems
        {
            get { return _myItems; }
            set { _myItems = value; }
        }
    }
    public class MyItem
    {
        public MyItem(double left, double top, string text)
        {
            Left = left;
            Top = top;
            Text = text;
        }

        public double Left { get; set; }
        public double Top { get; set; }
        public string Text { get; set; }
    }
}
