﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window23.xaml 的互動邏輯
    /// </summary>
    public partial class Window23 : Window
    {
        //选中控件的鼠标位置偏移量
        Point targetPoint;

        //选中控件
        UIElement targetElement;

        private void canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //确定选中控件，然后设置选中控件
            targetElement = Mouse.DirectlyOver as UIElement;
            if (targetElement != null)
                targetPoint = e.GetPosition(targetElement);
        }

        private void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            //鼠标松开后，将选中控件设置成null
            targetElement = null;
        }

        private void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            //确定鼠标左键处于按下状态并且有元素被选中
            if (e.LeftButton == MouseButtonState.Pressed && targetElement != null)
            {
                var pCanvas = e.GetPosition(canvas);
                //设置最终位置
                Canvas.SetLeft(targetElement, pCanvas.X - targetPoint.X);
                Canvas.SetTop(targetElement, pCanvas.Y - targetPoint.Y);
            }
        }
    }
}
