﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window33.xaml 的互動邏輯
    /// </summary>
    public partial class Window33 : Window
    {
        /// <summary>
        /// View 屬性變數Lines綁定用
        /// </summary>
        public ObservableCollection<Line> Lines { get; private set; }

        public Window33()
        {
             Lines = new ObservableCollection<Line>
            {
                new Line { From = new Point(100, 20), To = new Point(180, 180) },
                new Line { From = new Point(180, 180), To = new Point(20, 180) },
                new Line { From = new Point(20, 180), To = new Point(100, 20) },
                new Line { From = new Point(20, 50), To = new Point(180, 150) }
            };

            InitializeComponent();
            DataContext = this;
        }
    }
    public class Line
    {
        public Point From { get; set; }
        public Point To { get; set; }
    }
}
