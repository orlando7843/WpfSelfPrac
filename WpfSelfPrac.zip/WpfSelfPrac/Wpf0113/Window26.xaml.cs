﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window26.xaml 的互動邏輯
    /// </summary>
    public partial class Window26 : Window
    {
        public Window26()
        {
            InitializeComponent();
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("button1_MouseDown");
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("button1_MouseUp");
        }

        private void button1_MouseCaptureChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("button1_MouseCaptureChanged");
        }
    }
}
