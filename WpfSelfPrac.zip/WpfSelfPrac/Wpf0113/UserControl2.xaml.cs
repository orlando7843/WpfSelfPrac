﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// UserControl2.xaml 的互動邏輯
    /// </summary>
    public partial class UserControl2 : UserControl
    {
        

        public UserControl2()
        {
            InitializeComponent();
        }

        //位置用的相依屬性
        public static readonly DependencyProperty LocationProperty = DependencyProperty.Register(
            "Location", typeof(Point), typeof(UserControl2), new UIPropertyMetadata(default(Point), OnLocationChanged));

        //binding property
        public Point Location
        {
            get { return (Point)GetValue(LocationProperty); }
            set { SetValue(LocationProperty, value); }
        }

        private static void OnLocationChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control2 = (UserControl2)d;
            var value = (Point)e.NewValue;
            Canvas.SetLeft(control2, value.X);
            Canvas.SetTop(control2, value.Y);
        }
    }
}
