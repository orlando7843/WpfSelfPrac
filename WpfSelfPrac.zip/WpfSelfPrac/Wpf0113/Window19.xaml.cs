﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window19.xaml 的互動邏輯
    /// </summary>
    public partial class Window19 : Window
    {
        public Window19()
        {
            InitializeComponent();
        }
    }

    public class YesNoToBooleanConverter : IValueConverter
    {
        //Convert method gets called when source updates target object.
        //binding source:textbox, target object:TextBlock IsChecked property
        //we convert text value from textbox to boolean value to set IsChecked property.
        //value: TextBox value
        public object Convert(object value, Type targetType, 
                            object parameter, System.Globalization.CultureInfo culture)
        {
            switch (value.ToString().ToLower())
            {
                case "yes":
                case "oui":
                    return true;
                case "no":
                case "non":
                    return false;
            }
            return false;
        }

        //ConvertBack method gets called when target updates source object.
        //value: TextBlock value, Target: TextBox
        public object ConvertBack(object value, Type targetType, 
                            object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is bool)
            {
                if ((bool)value == true)
                    return "yes";
                else
                    return "no";
            }
            return "no";
        }
    }
}
