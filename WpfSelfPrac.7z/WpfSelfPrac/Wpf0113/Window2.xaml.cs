﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf0113
{
    /// <summary>
    /// Window2.xaml 的互動邏輯
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                ColumnDefinition colDef = new ColumnDefinition();
                myGrid.ColumnDefinitions.Add(colDef);
                RowDefinition rowDef = new RowDefinition();
                myGrid.RowDefinitions.Add(rowDef);
            }


            Random random = new Random();//隨機圖片檔

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    /*
                    Button btn = new Button();
                    btn.Content = string.Format("{0},{1}",i,j);
                    //透過代碼"修改" 按鈕的Grid.Row
                    //<Button Grid.Row="0">
                    Grid.SetRow(btn, i);//static method 把btn設在row index
                    Grid.SetColumn(btn, j);//把btn設在column index
                    myGrid.Children.Add(btn);*/
                    
                    int rndv = random.Next(1, 7);//random generate >=1 && <7
                    Image img = new Image();
                    img.Source = new BitmapImage(new Uri("images/"+rndv+".png",UriKind.Relative));
                    Grid.SetRow(img, i);
                    Grid.SetColumn(img, j);
                    myGrid.Children.Add(img);
                }
            }
            

            
        }
    }
}
