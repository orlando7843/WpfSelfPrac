﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using DevExpress.Xpf.Layout.Core;
using DevExpress.Xpf.Docking;
using DevExpress.Xpf.Docking.Platform;
using DevExpress.Xpf.Docking.VisualElements;


namespace BlackRectangles
{
    public partial class Demo_DockLayoutManager2 : Window
    {

        #region Panel layout

        private static LayoutGroup leftArea;
        private static LayoutGroup rightArea;
        private static LayoutGroup rightLeftArea;
        private static LayoutGroup rightRightArea;
        private static LayoutGroup leftLeftArea;
        private static LayoutGroup leftRightArea;


        private static TabbedGroup leftTopArea;
        private static TabbedGroup leftBottomArea;
        private static DocumentGroup centerArea;
        private static TabbedGroup bottomArea;
        private static TabbedGroup rightTopArea;
        private static TabbedGroup rightBottomArea;
        private List<LayoutPanel> layoutPanels;

        internal static LayoutGroup LeftArea
        {
            get { return leftArea; }
            set { leftArea = value; }
        }

        internal static LayoutGroup RightArea
        {
            get { return rightArea; }
            set { rightArea = value; }
        }

        internal static LayoutGroup RightLeftArea
        {
            get { return rightLeftArea; }
            set { rightLeftArea = value; }
        }

        internal static LayoutGroup RightRightArea
        {
            get { return rightRightArea; }
            set { rightRightArea = value; }
        }

        internal static LayoutGroup LeftLeftArea
        {
            get { return leftLeftArea; }
            set { leftLeftArea = value; }
        }

        internal static LayoutGroup LeftRightArea
        {
            get { return leftRightArea; }
            set { leftRightArea = value; }
        }

        internal static TabbedGroup LeftTopArea
        {
            get { return leftTopArea; }
            set { leftTopArea = value; }
        }

        internal static TabbedGroup LeftBottomArea
        {
            get { return leftBottomArea; }
            set { leftBottomArea = value; }
        }

        internal static DocumentGroup CenterArea
        {
            get { return centerArea; }
            set { centerArea = value; }
        }

        internal static TabbedGroup BottomArea
        {
            get { return bottomArea; }
            set { bottomArea = value; }
        }

        internal static TabbedGroup RightTopArea
        {
            get { return rightTopArea; }
            set { rightTopArea = value; }
        }

        internal static TabbedGroup RightBottomArea
        {
            get { return rightBottomArea; }
            set { rightBottomArea = value; }
        }

        #endregion


        public Demo_DockLayoutManager2()
        {
            InitializeComponent();

            dockLayoutManager.FloatingMode = FloatingMode.Desktop;
            dockLayoutManager.EnableWin32Compatibility = true;

            LeftArea = new LayoutGroup();
            LeftArea.Name = "LeftArea";
            LeftArea.ItemWidth = new GridLength(280);
            //LeftArea.DestroyOnClosingChildren = false;

            RightArea = new LayoutGroup();
            RightArea.Name = "RightArea";
            //RightArea.DestroyOnClosingChildren = false;

            RightLeftArea = new LayoutGroup();
            RightLeftArea.Name = "rightLeftArea";
            //RightLeftArea.DestroyOnClosingChildren = false;

            RightRightArea = new LayoutGroup();
            RightRightArea.Name = "rightRightArea";
            RightRightArea.ItemWidth = new GridLength(280);
            //RightRightArea.DestroyOnClosingChildren = false;


            LeftRightArea = new LayoutGroup();
            LeftRightArea.Name = "leftRightArea";
            //LeftRightArea.DestroyOnClosingChildren = false;

            LeftLeftArea = new LayoutGroup();
            LeftLeftArea.Name = "leftLeftArea";
            //LeftLeftArea.DestroyOnClosingChildren = false;

            LeftTopArea = new TabbedGroup();
            LeftTopArea.Name = "LeftTopArea";
            LeftTopArea.DestroyOnClosingChildren = false;

            LeftBottomArea = new TabbedGroup();
            LeftBottomArea.Name = "LeftBottomArea";
            //LeftBottomArea.DestroyOnClosingChildren = false;

            CenterArea = new DocumentGroup();
            CenterArea.Name = "CenterArea";
            //CenterArea.DestroyOnClosingChildren = false;

            BottomArea = new TabbedGroup();
            BottomArea.Name = "BottomArea";
            BottomArea.ItemHeight = new GridLength(280);
            //BottomArea.DestroyOnClosingChildren = false;

            RightTopArea = new TabbedGroup();
            RightTopArea.Name = "RightTopArea";
            //RightTopArea.DestroyOnClosingChildren = false;

            RightBottomArea = new TabbedGroup();
            RightBottomArea.Name = "RightBottomArea";
            //RightBottomArea.DestroyOnClosingChildren = false;

            dockLayoutManager.LayoutRoot.Name = "LayoutRoot";

            dockLayoutManager.DockController.Dock(RightArea, dockLayoutManager.LayoutRoot, DockType.Fill);
            dockLayoutManager.DockController.Dock(LeftArea, dockLayoutManager.LayoutRoot, DockType.Left);

            dockLayoutManager.DockController.Dock(RightLeftArea, RightArea, DockType.Fill);
            dockLayoutManager.DockController.Dock(RightRightArea, RightArea, DockType.Right);

            dockLayoutManager.DockController.Dock(LeftRightArea, LeftArea, DockType.Fill);
            dockLayoutManager.DockController.Dock(LeftLeftArea, LeftArea, DockType.Left);

            dockLayoutManager.DockController.Dock(LeftTopArea, LeftLeftArea, DockType.Fill);
            LeftTopArea.SetValue(AutoHideGroup.AutoHideTypeProperty, AutoHideType.Left);
            dockLayoutManager.DockController.Dock(LeftBottomArea, LeftLeftArea, DockType.Bottom);
            LeftBottomArea.SetValue(AutoHideGroup.AutoHideTypeProperty, AutoHideType.Left);

            dockLayoutManager.DockController.Dock(CenterArea, RightLeftArea, DockType.Fill);
            dockLayoutManager.DockController.Dock(BottomArea, RightLeftArea, DockType.Bottom);
            BottomArea.SetValue(AutoHideGroup.AutoHideTypeProperty, AutoHideType.Bottom);

            dockLayoutManager.DockController.Dock(RightTopArea, RightRightArea, DockType.Fill);
            RightTopArea.SetValue(AutoHideGroup.AutoHideTypeProperty, AutoHideType.Right);
            dockLayoutManager.DockController.Dock(RightBottomArea, RightRightArea, DockType.Bottom);
            RightTopArea.SetValue(AutoHideGroup.AutoHideTypeProperty, AutoHideType.Right);

            layoutPanels = new List<LayoutPanel>();
            CreateLayoutPanels();
        }

        private void CreateLayoutPanels()
        {
            LayoutPanel layoutPanel1 = new LayoutPanel() { Caption = "TopLeft 1" };
            layoutPanel1.Content = null;
            layoutPanels.Add(layoutPanel1);
            dockLayoutManager.DockController.Dock(layoutPanel1, LeftTopArea, DockType.Fill);

            LayoutPanel layoutPanel2 = new LayoutPanel() { Caption = "TopLeft 2" };
            layoutPanels.Add(layoutPanel2);
            dockLayoutManager.DockController.Dock(layoutPanel2, LeftTopArea, DockType.Fill);


            LayoutPanel bottomLeft1 = new LayoutPanel() { Caption = "BottomLeft 1" };
            layoutPanels.Add(bottomLeft1);
            dockLayoutManager.DockController.Dock(bottomLeft1, LeftBottomArea, DockType.Fill);

            LayoutPanel bottomLeft2 = new LayoutPanel() { Caption = "BottomLeft 2" };
            layoutPanels.Add(bottomLeft2);
            dockLayoutManager.DockController.Dock(bottomLeft2, LeftBottomArea, DockType.Fill);

            LayoutPanel bottomLeft3 = new LayoutPanel() { Caption = "BottomLeft 3" };
            layoutPanels.Add(bottomLeft3);
            dockLayoutManager.DockController.Dock(bottomLeft3, LeftBottomArea, DockType.Fill);

            LayoutPanel topRight1 = new LayoutPanel() { Caption = "TopRight 1" };
            layoutPanels.Add(topRight1);
            dockLayoutManager.DockController.Dock(topRight1, RightTopArea, DockType.Fill);

            LayoutPanel topRight2 = new LayoutPanel() { Caption = "TopRight 2" };
            layoutPanels.Add(topRight2);
            dockLayoutManager.DockController.Dock(topRight2, RightTopArea, DockType.Fill);

            LayoutPanel topRight3 = new LayoutPanel() { Caption = "TopRight 3" };
            layoutPanels.Add(topRight3);
            dockLayoutManager.DockController.Dock(topRight3, RightTopArea, DockType.Fill);

            LayoutPanel bottomRight1 = new LayoutPanel() { Caption = "BottomRight 1" };
            layoutPanels.Add(bottomRight1);
            dockLayoutManager.DockController.Dock(bottomRight1, RightBottomArea, DockType.Fill);

            LayoutPanel bottomRight2 = new LayoutPanel() { Caption = "BottomRight 2" };
            layoutPanels.Add(bottomRight2);
            dockLayoutManager.DockController.Dock(bottomRight2, RightBottomArea, DockType.Fill);

            LayoutPanel bottom1 = new LayoutPanel() { Caption = "Bottom 1" };
            layoutPanels.Add(bottom1);
            dockLayoutManager.DockController.Dock(bottom1, BottomArea, DockType.Fill);

            LayoutPanel bottom2 = new LayoutPanel() { Caption = "Bottom 2" };
            layoutPanels.Add(bottom2);
            dockLayoutManager.DockController.Dock(bottom2, BottomArea, DockType.Fill);
        }

        private void dockLayoutManager_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (dockLayoutManager.AutoHideGroups.Count == 0)
                {
                    AutoHide();
                }
                else
                {
                    AutoRestore();
                }
            }
            else if (e.Key == Key.F1)
            {
                MessageBox.Show("Help Requested");
            }
        }

        private void AutoHide()
        {
            foreach (LayoutPanel layoutPanel in layoutPanels)
            {
                if (!(layoutPanel.Parent is DocumentGroup)
                        && !(layoutPanel.Parent is AutoHideGroup)
                        && !layoutPanel.IsFloating)
                {
                    if (layoutPanel.Parent.Name != null
                    && layoutPanel.Parent.Name.Equals("LayoutRoot"))
                    {
                        dockLayoutManager.DockController.Hide(layoutPanel);
                    }
                    else
                    {
                        dockLayoutManager.DockController.Hide(layoutPanel.Parent);
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void AutoRestore()
        {
            foreach (LayoutPanel layoutPanel in layoutPanels)
            {
                if (layoutPanel.IsAutoHidden)
                {
                    if (layoutPanel.Parent.Name != null
                        && layoutPanel.Parent.Name.Equals("LayoutRoot"))
                    {
                        dockLayoutManager.DockController.Dock(layoutPanel);
                    }
                    else
                    {
                        dockLayoutManager.DockController.Dock(layoutPanel.Parent);
                    }
                }
            }
        }



        private void dockLayoutManager_PreviewDragEnter(object sender, DragEventArgs e)
        {
            DockLayoutManager manager = sender as DockLayoutManager;
            BaseLayoutItem elem = e.Source as BaseLayoutItem;
            if (manager != null && elem != null)
            {
                LayoutElementHitInfo info = manager.CalcHitInfo(e.GetPosition(this));
                manager.Activate(elem);
                if (info.InHeader)
                {
                    TabbedPaneItem item = (info.Element as TabbedPaneItemElement).Element as TabbedPaneItem;
                    if (item != null && item.DataContext != null && item.DataContext is BaseLayoutItem)
                        manager.DockController.Activate(item.DataContext as BaseLayoutItem);
                }
            }

        }







    }
}
