﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoToolBox
{
    /// <summary>
    /// ToolBoxView.xaml 的互動邏輯
    /// </summary>
    public partial class ToolBoxView : UserControl
    {
        private DesignTimeToolboxViewModel _viewModel;
        public ToolBoxView()
        {
            InitializeComponent();
            _viewModel = new DesignTimeToolboxViewModel();
            base.DataContext = _viewModel;

            /* 搬給ViewModel處理
            System.ComponentModel.ICollectionView view = CollectionViewSource.GetDefaultView(_viewModel.Items);
            view.GroupDescriptions.Add(new PropertyGroupDescription("Category"));
            listBox.ItemsSource = view;*/
        }
    }
}
