﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoToolBox
{

    public class ToolBoxViewModel //: INotifyPropertyChanged
    {
    }

    public class DesignTimeToolboxViewModel : INotifyPropertyChanged
    {   
        public string StrVisible { get; set; }

        private ObservableCollection<ToolboxItemViewModel> _items;//2F root
        public ObservableCollection<ToolboxItemViewModel> Items
        {
            get { return _items; }
        }

        private System.ComponentModel.ICollectionView _view;
        public System.ComponentModel.ICollectionView View
        {
            get { return _view; }
            set { _view = value; OnNotifyPropertyChanged("View"); }
        }

        public DesignTimeToolboxViewModel()
        //: base(null, null)
        {
            StrVisible = "Visible";//"Collapsed";
            //[ToolboxItem(typeof(GraphViewModel), "Multiply", "Maths", "pack://application:,,,/Modules/FilterDesigner/Resources/active_x_16xLG.png")]
            _items = new ObservableCollection<ToolboxItemViewModel>();
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "設On", Category = "按鈕", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image001.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "設Off", Category = "按鈕", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image002.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "保持型", Category = "按鈕", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image003.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "交替型", Category = "按鈕", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image004.png") }));

            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "數值輸入", Category = "輸入", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image005.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "文數字輸入", Category = "輸入", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image006.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "Barcode輸入", Category = "輸入", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image007.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "多語輸入", Category = "輸入", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image008.png") }));

            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "歷史警報表", Category = "警報顯示", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image009.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "當前警報表", Category = "警報顯示", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image010.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "警報頻次表", Category = "警報顯示", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image011.png") }));
            _items.Add(new ToolboxItemViewModel(new ToolboxItem { Name = "警報訊息走馬燈", Category = "警報顯示", IconSource = new Uri("pack://application:,,,/HMI/Images/Toolbox/image012.png") }));

            _view = System.Windows.Data.CollectionViewSource.GetDefaultView(Items);
            _view.GroupDescriptions.Add(new System.Windows.Data.PropertyGroupDescription("Category"));

        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnNotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

    public class ToolboxItemViewModel
    {
        private readonly ToolboxItem _model;

        public ToolboxItem Model//1F
        {
            get { return _model; }
        }

        public string Name//寫死0F  leaf
        {
            get { return _model.Name; }
        }

        public virtual string Category//寫死0F
        {
            get { return _model.Category; }
        }

        public virtual Uri IconSource
        {
            get { return _model.IconSource; }
        }

        public ToolboxItemViewModel(ToolboxItem model)
        {
            _model = model;
        }
    }

    public class ToolboxItem
    {
        public Type DocumentType { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public Uri IconSource { get; set; }
        public Type ItemType { get; set; }
    }

}

namespace DemoToolBox
{
    public class ExpanderEx : System.Windows.Controls.Expander
    {
        static ExpanderEx()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ExpanderEx),
                new System.Windows.FrameworkPropertyMetadata(typeof(ExpanderEx)));
        }
    }
}